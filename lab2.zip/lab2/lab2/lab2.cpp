﻿#include <fstream>
#include <iostream>

using namespace std;

void GetMatr(int** mat, int** temp, int i, int j, int n) {
	int ki, kj, di, dj;
	di = 0;
	for (ki = 0; ki < n - 1; ++ki) {
		if (ki == i) 
			di = 1;
		dj = 0;
		for (kj = 0; kj < n - 1; ++kj) {
			if (kj == j) 
				dj = 1;
			temp[ki][kj] = mat[ki + di][kj + dj];
		}
	}
}

int Determinant(int **mat, int n) {
	int det = 0;
	int k = 1;
	int m = n - 1;
	int **temp;
	temp = new int*[n];
	for (int i = 0; i < n; ++i) {
		temp[i] = new int[n];
	}
	if (n == 1) {
		det = mat[0][0];
		return det;
	}
	if (n == 2) {
		det = mat[0][0] * mat[1][1] - (mat[0][1]*mat[1][0]);
		return det;
	}
	for (int i = 0; i < n; ++i) {
		GetMatr(mat, temp, i, 0, n);
		det = det + mat[i][0] * k * Determinant(temp, m);
		k = -k;
	}
	return det;
}

int Check(int &x) {
	while (true) {
		if (cin.fail()) {
			cin.clear();
			cin.ignore();
			cout << "Неправильный ввод. Попробуйте ещё раз:  ";
			cin >> x;
		}
		else {
			if (x > 0) {
				break;
			}
			else {
				cout << "Неправильный ввод. Попробуйте ещё раз:  ";
				cin >> x;
			}
		}
	}
	return x;
}
int CheckMat(int &x) {
	while (true) {
		if (cin.fail()) {
			cin.clear();
			cin.ignore();
			cout << "Неправильный ввод. Попробуйте ещё раз:  ";
			cin >> x;
		}
		else {
			break;
		}
	}
	return x;
}

int main()
{
	int f = 0;
	int n = 0;
	int ** mat;
	int a = 0;
	setlocale(LC_ALL, "RUS");
	cout << "Введите 1, если ввод через консоль, 0 если из файла: ";
	cin >> f;
	while (true) {
		if (cin.fail()) {
			cin.clear();
			cin.ignore();
			cout << "Неправильный ввод. "<< endl;
			cout << "Введите 1, если ввод через консоль, 0 если из файла: ";
			cin >> f;
		}
		else {
			if ((f == 1) || (f == 0)) {
				break;
			}
			else {
				cout << "Неправильный ввод. " << endl;
				cout << "Введите 1, если ввод через консоль, 0 если из файла: ";
				cin >> f;
			}
		}
	}
	if (f == 1) {
		cout << "Введите размер матрицы ";
		cin >> n;
		Check(n);
		mat = new int*[n];
		for (int i = 0; i < n; ++i) {
			mat[i] = new int[n];
			for (int j = 0; j < n; ++j) {
				cout << "mat[" << i+1 << "][" << j+1 << "]= ";
				cin >> mat[i][j];
				CheckMat(mat[i][j]);
			}
		}
		cout <<"Определитель равен: "<< Determinant(mat, n);
	}
	if (f == 0) {
		ifstream fin("lab2.txt");
		string s;
		fin >> n;
		if ((fin.fail())||(n < 1)) {
			cout << "Ошибка. Неправильные данные в файле." << std::endl;
			return 0;
		}
		mat = new int*[n];
		for (int i = 0; i < n; ++i) {
			mat[i] = new int[n];
			for (int j = 0; j < n; ++j) {
				fin >> mat[i][j];
				if (fin.fail()) {
					cout << "Ошибка. Неправильные данные в файле." << std::endl;
					return 0;
				}
				cout << "mat[" << i + 1 << "][" << j + 1 << "]= ";
				cout << mat[i][j] << endl;
			}
		}
	}
}

